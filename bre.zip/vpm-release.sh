#!/usr/bin/env bash
set -euo pipefail

PACKAGE_PATH="Packages/com.heftwig.advandism-avatar-optimizer"
PACKAGE_JSON="$PACKAGE_PATH/package.json"
RELEASE_WORKFLOW="Build Release"
LISTING_WORKFLOW="Build Repo Listing"
BRANCH="main"

VERSION_INPUT="${1:-}"
CUSTOM_MSG="${2:-}"

if [[ -z "$VERSION_INPUT" ]]; then
  read -rp "Enter new version, or type patch/minor/major: " VERSION_INPUT
fi

CURRENT_VERSION="$(python3 -c "import json; print(json.load(open('$PACKAGE_JSON'))['version'])")"
PACKAGE_NAME="$(python3 -c "import json; print(json.load(open('$PACKAGE_JSON'))['name'])")"

bump_version() {
  python3 - "$CURRENT_VERSION" "$VERSION_INPUT" <<'PY'
import sys

current = sys.argv[1]
mode = sys.argv[2]

parts = current.split(".")
if len(parts) != 3 or not all(p.isdigit() for p in parts):
    raise SystemExit(f"Current version is not simple semver: {current}")

major, minor, patch = map(int, parts)

if mode == "patch":
    patch += 1
elif mode == "minor":
    minor += 1
    patch = 0
elif mode == "major":
    major += 1
    minor = 0
    patch = 0
else:
    print(mode)
    raise SystemExit(0)

print(f"{major}.{minor}.{patch}")
PY
}

if [[ "$VERSION_INPUT" == "patch" || "$VERSION_INPUT" == "minor" || "$VERSION_INPUT" == "major" ]]; then
  NEW_VERSION="$(bump_version)"
else
  NEW_VERSION="$VERSION_INPUT"
fi

if [[ ! "$NEW_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "ERROR: Version must look like 1.0.1, or be patch/minor/major."
  exit 1
fi

COMMIT_MSG="${CUSTOM_MSG:-Update to $NEW_VERSION}"

echo "Package: $PACKAGE_NAME"
echo "Current version: $CURRENT_VERSION"
echo "New version: $NEW_VERSION"
echo "Commit message: $COMMIT_MSG"
echo

if [[ "$NEW_VERSION" == "$CURRENT_VERSION" ]]; then
  echo "ERROR: New version is the same as current version."
  exit 1
fi

if gh release view "$NEW_VERSION" >/dev/null 2>&1; then
  echo "ERROR: Release $NEW_VERSION already exists on GitHub."
  exit 1
fi

echo "==> Updating package.json version..."
python3 - "$PACKAGE_JSON" "$NEW_VERSION" <<'PY'
import json
import sys

path = sys.argv[1]
new_version = sys.argv[2]

with open(path, "r", encoding="utf-8") as f:
    data = json.load(f)

data["version"] = new_version

with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2)
    f.write("\n")
PY

echo "==> Adding files..."
git add -A

if git diff --cached --quiet; then
  echo "ERROR: No changes to commit."
  exit 1
fi

echo "==> Committing..."
git commit -m "$COMMIT_MSG"

echo "==> Pushing..."
git push origin "$BRANCH"

echo "==> Running release workflow..."
gh workflow run "$RELEASE_WORKFLOW" --ref "$BRANCH"
sleep 5
RELEASE_RUN_ID="$(gh run list --workflow "$RELEASE_WORKFLOW" --branch "$BRANCH" --event workflow_dispatch --limit 1 --json databaseId --jq '.[0].databaseId')"
gh run watch "$RELEASE_RUN_ID" --exit-status

echo "==> Running VPM listing workflow..."
gh workflow run "$LISTING_WORKFLOW" --ref "$BRANCH"
sleep 5
LISTING_RUN_ID="$(gh run list --workflow "$LISTING_WORKFLOW" --branch "$BRANCH" --event workflow_dispatch --limit 1 --json databaseId --jq '.[0].databaseId')"
gh run watch "$LISTING_RUN_ID" --exit-status

echo
echo "Done."
echo "Release:"
echo "https://github.com/Heftwig/Advandism-Avatar-Optimizer/releases/tag/$NEW_VERSION"
echo
echo "VPM index:"
echo "https://heftwig.github.io/Advandism-Avatar-Optimizer/index.json"
